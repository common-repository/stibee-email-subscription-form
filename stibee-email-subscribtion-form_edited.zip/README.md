# Outdated Notice

Sample plugin using the WordPress plugin boilerplate where the user can customize the plugin for the position of the text notice as well as the day treshold for a post to be considered as outdated.

This code is used as a support for article series "Speed up Development Using the WordPress Plugin Boilerplate" for [SitePoint](http://www.sitepoint.com/)

Article in series:
* [Part 1](http://www.sitepoint.com/wordpress-plugin-boilerplate/)
* Part 2 - [Code](https://github.com/fsylum/wp-stibee/tree/part-2)
