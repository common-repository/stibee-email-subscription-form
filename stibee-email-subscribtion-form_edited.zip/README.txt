=== 스티비 구독 폼 ===
Contributors: sitbee
Donate link: https://stibee.com
Tags: email, marketing, stibee, 이메일, 마케팅, 스티비, 
Requires at least: 3.0.1
Tested up to: 5.2.1
Requires PHP: 5.2.4
Stable tag: 5.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Here is a short description of the plugin.  This should be no more than 150 characters.  No markup here.

== Description ==

이메일 마케팅 서비스 스티비(stibee.com)의 구독 폼 생성 및 위젯 플러그인입니다.

*   stibee.com의 주소록과 연동된 구독 폼 위젯과 숏코드를 생성할 수 있습니다.
*   구독 폼 위젯을 웹사이트의 사이드바 등에 노출할 수 있습니다.
*   별도로 제공되는 숏코드를 페이지 등에 삽입하여 구독 폼을 노출할 수 있습니다.
*   위젯을 통해 수집된 구독자 정보(이메일, 이름 등)는 스티비의 지정된 주소록에 저장됩니다.
*   수집하고자 하는 구독자 정보 필드를 설정할 수 있습니다.
*   구독 폼의 디자인을 설정할 수 있습니다.


== Installation ==

1. 스티비 구독 폼 플러그인 파일을 FTP plugins 디렉토리에 업로드 하거나 워드프레스 관리자 페이지의 플러그인 메뉴에서 업로드하거나, 또는 플러그인 마켓에서 "스티비 구독 폼"을 검색하여 설치합니다.
1. 설치가 완료된 후 플러그인 활성화합니다.
1. [계정 연결] 메뉴에서 스티비에서 발급받은 API 키를 입력하여 계정을 연결합니다.
1. API 키는 스티비 로그인 후 [계정 및 결제] > [API 키]에서 만들 수 있습니다. 자세한 내용은 주소록 API 사용하기를 참고하세요
1. [주소록 선택] 메뉴에서 연동하려는 주소록을 선택합니다.
1. [디자인] 메뉴에서 위젯에 표시할 필드(수집하려는 필드)를 선택하고, 구독 폼의 제목과 내용, 디자인을 설정합니다.
1. [외모] > [위젯] 메뉴에서 "스티비 구독 폼" 위젯을 원하는 곳에 배치합니다.
1. 또는 숏코드 [stibee_form]를 원하는 페이지 등에 입력하여 구독 폼을 노출합니다.


== Screenshots ==

1. `/assets/screenshot1.png`

== Changelog ==

= 1.0 =
* 최초 배포
